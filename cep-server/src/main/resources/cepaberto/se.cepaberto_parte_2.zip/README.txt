Olá,

Esta base de dados de CEPs foi gerada pelo CEP Aberto, http://www.cepaberto.com.
Você pode retribuir para o CEP Aberto melhorando a qualidade das informações de
ruas, bairros, cidades que você conhece acessando http://www.cepaberto.com/ceps.
A cada dia, um dump novo está disponível com dados atualizados.

Estes dados são disponibilizados sob licença Open Database License (ODbL):
http://opendatacommons.org/licenses/odbl/1.0/

Caso esta base de dados seja útil pra você, peço que faça uma doação para manter
o serviço como está hoje, em pleno funcionamento.

Se puder, divulgue o CEP Aberto, pois ele é um projeto feito por uma só pessoa
com o intuito de prover gratuitamente a base de CEPs correta e atualizada.

Abraços,

Eduardo.